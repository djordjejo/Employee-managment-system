﻿namespace employee_management_system_b.DTO
{
    public class ShowEmployeeDTO
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
    }
}
