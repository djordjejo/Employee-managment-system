﻿namespace employee_management_system_b.DTO
{
    public class CreateEmployeeDTO
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string EmployeeDepartment { get; set; }
        public IEnumerable<string> EmployeeProject { get; set; }

    }
}
