﻿using employee_management_system_b.Models;
using employee_management_system_b.Repositories.IRepository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace employee_management_system_b.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        private readonly IUnitOfWork _unitOfWork;
        public EmployeesController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(_unitOfWork.Employees.GetAll());
        }

        [HttpGet]
        [Route("{id:guid}")]
        public IActionResult GetEmployee(Guid id) {

            if (id == Guid.Empty) 
                return BadRequest("Invalid ID");

            var employee = _unitOfWork.Employees.GetById(id);

            if (employee == null)
                return NotFound();

            return Ok(employee);


        }

        [HttpPost]
        public IActionResult CreateEmployee([FromBody] EmployeeDTO)
    }
}
