﻿namespace employee_management_system_b.Repositories.IRepository
{
    public interface IRepository<T> where T : class
    {
        void Add(T entity);
        void Update(T entity);
        void Delete(T entity);
        T GetById(Guid id);
         Task<IEnumerable<T>> GetAll();
        void DeleteAll();

    }
}
